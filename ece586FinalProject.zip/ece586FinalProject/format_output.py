out = open("results.csv", "w")
out.write("Branch,Actual Branch Outcome,Prediction,Correct? [Y/N]\n")

count = 0

with open("output.txt", "r") as f:
    lines = f.readlines()
    for line in lines:
        if line[0] == 'x':
            continue
        
        branch = "B1"
        outcome = "NT"
        prediction = "NT"
        hit = "N"
        
        if line[0] == '1':
            branch = "B2"
        if line[1] == '1':
            outcome = "T"
        if line[2] == '1':
            prediction = "T"
        if line[3] == '1':
            hit = "Y"
            count += 1
        
        out.write(branch+","+outcome+","+prediction+","+hit+"\n")
    
    print("Number of hits:",count)
    print("Number of misses:",(len(lines)-1-count))
    print("Hit rate:",str((count/(len(lines)-1))*100)+"%")
